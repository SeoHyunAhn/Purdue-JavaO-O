/**
 * Created by zhangjunyi on 16/10/24.
 */
import java.awt.*;
import javax.swing.*;
public class PlayGameFrame extends JFrame{
    private JLabel username = new JLabel("Bob");
    private JLabel item4 = new JLabel("Welcome!");
    private JButton item2 = new JButton("Start New Game");
    private JButton item3 = new JButton("Join a Game");
    private JPanel panel1 = new JPanel();
    private JPanel panel2 = new JPanel(new GridBagLayout());
    private JPanel panel3 = new JPanel(new BorderLayout());

    public PlayGameFrame() {
        //title
        super("FoilMaker");

        //Username
        panel1.add(username);
        add(panel1, BorderLayout.NORTH);

        // Two Buttons
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        panel2.add(item2,c);
        c.gridx = 1;
        c.gridy = 0;
        panel2.add(item3,c);
        panel2.setBorder(BorderFactory.createEtchedBorder());
        add(panel2,BorderLayout.CENTER);

        //Welcome!
        panel3.add(item4);
        add(panel3, BorderLayout.SOUTH);
    }
    public static void main(String[] args) {
        PlayGameFrame n = new PlayGameFrame();
        n.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        n.setSize(400,600);
        n.setVisible(true);
    }
}
