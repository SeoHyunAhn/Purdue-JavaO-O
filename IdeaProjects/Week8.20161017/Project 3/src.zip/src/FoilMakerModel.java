import java.util.ArrayList;

/**
 * Created by student on 10/25/16.
 */
public class FoilMakerModel {
    String[] list= new String[]{"Bob:bob123:0:0:0", "Alice:alice123:0:0:0"};
    String name, code;
    public void FoilMakerModel(){}
    public void getUser(String name, String code){
        this.name=name;
        this.code=code;

    }

}
