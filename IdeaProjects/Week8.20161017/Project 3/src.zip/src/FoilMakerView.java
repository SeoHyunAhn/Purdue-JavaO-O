import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static org.apache.sanselan.util.Debug.newline;
import static org.mozilla.javascript.ScriptRuntime.add;

public class FoilMakerView extends JFrame implements ActionListener{
    JFrame frame;
    JTextField field, PW;
    JLabel labelID, labelPW;
    JButton Loginbutton, regbutton;
    private JPanel panel1 = new JPanel();
    private JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
    private JPanel panel3=new JPanel(new FlowLayout(FlowLayout.CENTER));
    private JLabel item1 = new JLabel("FoilMaker");
    private JLabel item2 = new JLabel("Welcome");
    JTextField  testField = new JTextField(999);
    String username, password, msg, RequestUser, item2msg;
    private JTextArea output;
    FoilMakerController controller;

    public void FoilMakerView(){
        controller=new FoilMakerController();
        frame=new JFrame("FoilMaker");
    }
    public void FoilMakerLogin(){
        panel1.add(item1);
        labelID=new JLabel("Name: ");
        field=new JTextField("Enter Name");
        username=field.getText();
        labelPW=new JLabel("PassWord: ");

        PW=new JTextField("Enter Password");
        password=PW.getText();//constant는 가능 많이 바뀐다면 모델로

        Loginbutton=new JButton("Login");
        Loginbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ButtonLoginRegister(e);
            }
        });
        regbutton=new JButton("Register");
        panel3.add(regbutton);
        JPanel tempPanel =new JPanel(new GridBagLayout());
        GridBagConstraints c= new GridBagConstraints();
        c.fill =GridBagConstraints.HORIZONTAL;
        c.gridx=1;
        c.gridy=0;
        tempPanel.add(labelID,c);


        c.fill =GridBagConstraints.HORIZONTAL;
        c.weightx=0.5;
        c.gridx=3;
        c.gridwidth=2;
        c.gridy=0;
        tempPanel.add(field,c);

        c.fill =GridBagConstraints.HORIZONTAL;
        c.gridx=1;
        c.gridwidth=2;
        c.gridy=1;
        tempPanel.add(labelPW,c);

        c.fill =GridBagConstraints.HORIZONTAL;
        c.weightx=0.5;
        c.gridx=3;
        c.gridy=1;
        tempPanel.add(PW,c);

        c.gridx=2;
        c.gridy=4;
        tempPanel.add(Loginbutton, c);

        c.fill =GridBagConstraints.HORIZONTAL;
        c.gridx=3;
        c.gridy=4;
        tempPanel.add(regbutton, c);


        panel2.add(item2);
        panel2.setBorder(BorderFactory.createEtchedBorder());
        panel1.setBorder(BorderFactory.createEtchedBorder());
        add(panel1, BorderLayout.NORTH);
        add(tempPanel, BorderLayout.CENTER);
        add(panel2, BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public void FoilMakerGamestart(){}
    private void ButtonLoginRegister(ActionEvent e) {
        FoilMakerClient.FoilMakerLogin_buttonLogin(e);
        }

    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source instanceof JButton) {
            ButtonLoginRegister(e);
        }
    }


    public void showMessage(String msg) {
        output.append(msg);
    }

//    public static void main(String[] args) {
//        FoilMakerView es =new FoilMakerView();
//        es.setSize(400,600);
//        es.setVisible(true);
//    }





}