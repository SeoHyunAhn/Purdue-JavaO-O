/**
 * Created by zhangjunyi on 16/10/24.
 */
import java.awt.*;
import javax.swing.*;
public class StartAnewGameFrame extends JFrame{
    private JLabel username = new JLabel("Bob");
    private JLabel item2 = new JLabel("Others should use this key to join your game");

    private JTextField item3 = new JTextField();// 生成三个随机character
    private JButton item4 = new JButton("Start Game");

    private JLabel item5 = new JLabel("Game started: Your are the leader");
    private JPanel panel1 = new JPanel();
    private JPanel panel2 = new JPanel(new GridBagLayout());
    private JPanel panel3 = new JPanel();
    private JPanel panel4 = new JPanel(new BorderLayout());


    public StartAnewGameFrame(){
        //Title
        super("FoilMaker");

        //Username
        panel1.add(username);
        add(panel1,BorderLayout.NORTH);


        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10,10,10,10);
        c.gridy=0;
        c.gridx=0;
        panel2.add(item2,c);
        c.gridx=0;
        c.gridy=1;

        panel2.add(item3,c);
        panel2.setBorder(BorderFactory.createEtchedBorder());

        panel3.setBorder(BorderFactory.createTitledBorder("Participants"));
        panel3.setPreferredSize(new Dimension(300,200));
        panel3.setBackground(Color.white);
        item3.setBackground(Color.lightGray);
        item3.setPreferredSize(new  Dimension(290,170));
        panel3.add(item3);
        c.gridx=0;
        c.gridy=2;
        panel2.add(panel3,c);

        c.gridx=0;
        c.gridy=3;
        panel2.add(item4,c);
        add(panel2);


        //Game started: you are the leader
        panel4.add(item5);
        add(panel4,BorderLayout.SOUTH);

    }

    public static void main(String[] args) {
        StartAnewGameFrame s = new StartAnewGameFrame();
        s.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        s.setSize(400,600);
        s.setVisible(true);
    }
}
