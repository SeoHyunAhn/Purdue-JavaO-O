import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.ServerSocket;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by student on 10/25/16.
 */
public class FoilMakerController {
    PrintWriter out;
    InputStreamReader isr;
    BufferedReader in;
    String serverMessage;

    public void ConnecttoServer() {
        String serverIP="localhost";
        int serverPort=9999;
        try{
            Socket socket =new Socket(serverIP, serverPort);
            out =new PrintWriter(socket.getOutputStream(), true);
            isr=new InputStreamReader(socket.getInputStream());
            in =new BufferedReader(isr);
        //    out.println("  ");
        //    serverMessage =in.readLine();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void sendMessage(String message) {
        out.println(message);
    }
    public String receiveMessage(){
        try {
            return in.readLine();
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }
//    public boolean registUser() {
//
//    }
//    public void addController(FoilMakerController controller){
//    this.controller = controller;
//    }
//    public void userRequest(String msg, String name, String pw){
//        RequestUser= msg+"--"+name+"--"+pw;
//    }

    public static class EchoServer{
        public static void main(String args[])
        {
            int port = 0;
            if(args.length == 0){
                System.out.println("No port provided, using a random free port");
            }else{
                try{
                    port = Integer.parseInt(args[0]);
                }catch(NumberFormatException e){
                    System.err.printf("Invalid port number \"%s\", must be an integer%n", args[0]);
                    return;
                }
                if(port <0 || port > 65535){
                    System.err.printf("Invalid port number %d, must be in range 0 - 65535%n", port);
                    return;
                }
            }
            if(port != 0){
                System.out.println("opening server on port " + port);
            }else{
                System.out.println("opening server on a random port");
            }

            try(ServerSocket  ss= new ServerSocket(port)){
                System.out.println("server listening on port " + ss.getLocalPort());
                while(true){
                    try(Socket s = ss.accept()){

                        System.out.printf("%s connected%n", s.getRemoteSocketAddress());

                        OutputStream os;
                        InputStream is;

                        try{
                            is= s.getInputStream();
                        }catch(IOException e){
                            System.err.println("Failed to get InputStream:");
                            e.printStackTrace();
                            return;
                        }
                        try{
                            os= s.getOutputStream();
                        }catch(IOException e){
                            System.err.println("Failed to get OutputStream:");
                            e.printStackTrace();
                            return;
                        }

                        byte[] buffer = new byte[4096];
                        int read;

                        try{
                            while((read = is.read(buffer)) >=0 ){
                                try{
                                    os.write(buffer, 0 , read);
                                    System.out.write(buffer , 0 , read);
                                    System.out.flush();
                                    os.flush();
                                }catch(IOException e){
                                    System.err.println("Failed to write");
                                    e.printStackTrace();
                                    return;
                                }
                            }
                        }catch(IOException e){
                            System.err.println("Failed to read:");
                            e.printStackTrace();
                            return;
                        }


                    }catch(IOException e){
                        System.err.println("An exception occured while waiting for a connection:");
                        e.printStackTrace();
                        return;
                    }
                    System.out.println();
                    System.out.println("Connection closed");
                }
            }catch(IOException e){
                System.err.println("Failed to open socket:");
                e.printStackTrace();
                return;
            }
        }
    }

}
