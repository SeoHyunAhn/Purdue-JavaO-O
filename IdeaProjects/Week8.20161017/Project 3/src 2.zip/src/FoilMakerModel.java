import com.sun.jna.platform.win32.Netapi32Util;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

/**
 * Created by student on 10/25/16.
 */
public class FoilMakerModel {
    JTextField field, PW;
    JButton Loginbutton, regbutton,  NewGame, JoinGame, StartGame;
    public JPanel panel1 = new JPanel();
    public JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
    public JPanel panel3=new JPanel(new FlowLayout(FlowLayout.CENTER));
    public JLabel item1 = new JLabel("FoilMaker");
    public JLabel item2 = new JLabel("Welcome");
    JTextField  testField = new JTextField(999);
    String username, password, msg, RequestUser, USERTOKEN, requestNewGame, GAMETOKEN, requestJoinGame, PaticipantGame;
    FoilMakerController controller;


    public void addController(FoilMakerController controller){
        this.controller = controller;
    }
    public void userRequest(String msg, String username, String password) {
        RequestUser= msg+"--"+username+"--"+password;
    }
    public void GameRequest (String msg, String tk){
        requestNewGame=msg+"--"+tk;
    }
    public void JoinGameRequest (String msg, String tk, String Gametk){
        requestJoinGame=msg+"--"+tk+"--"+Gametk;
    }
    public void AllParticipantRequest(String msg, String tk, String Gametk){PaticipantGame=msg+"--"+tk+"--"+Gametk;}

    public void FoilMakerLogin_buttonLogin(ActionEvent e){
        controller.ConnecttoServer();
        addController(controller);// 보통 client에 들어가는 것들 (연결확인 이런ㄱ
        JButton click = (JButton) e.getSource();
        if (click==Loginbutton){
            msg = "LOGIN";
            username=field.getText();
            password=PW.getText();
            userRequest(msg, username, password);
            controller.sendMessage(RequestUser);
            String received1=controller.receiveMessage();//네트워크랑 연결하는 method 수현식 여기다 연결해놓을 것
            System.out.print(received1);
            String[] parts = received1.split("--");
            if (parts[2].equals("INVALIDMESSAGEFPRMAT")){
                item2.setText("Invalid format");
            } else if (parts[2].equals("UNKNOWNUSER")){
                item2.setText("Invalid user");}
            else if (parts[2].equals("INVALIDUSERPASSWORD")){
                item2.setText("Invalid Password");}
            else if (parts[2].equals("USERALREADYLOGGEDIN")){
                item2.setText("User already logged in");
            }
            else if (parts[2].equals("SUCCESS")){
                item2.setText(username+" logging in");
                USERTOKEN=parts[3];
            }
        }
        else if (click==regbutton){
            msg = "CREATENEWUSER";
            userRequest(msg, username, password);
            controller.sendMessage(RequestUser);
            String received2=controller.receiveMessage();//네트워크랑 연결하는 method 수현식 여기다 연결해놓을 것
            String[] parts = received2.split("--");
            if (parts[2].equals("INVALIDMESSAGEFPRMAT")){
                item2.setText("Invalid format");
            } else if (parts[2].equals("INVALIDUSERNAME"))
                item2.setText("Username is empty");
            else if (parts[2].equals("INVALIDUSERPASSWORD"))
                item2.setText("Password\tempty");
            else if (parts[2].equals("USERALREADYEXISTS"))
                item2.setText("User already exist");
            else if (parts[2].equals("SUCCESS")){
                item2.setText(username+" logging in");
                USERTOKEN=parts[3];}
        }

    }

    public void FoilMakerGame_buttonGame(ActionEvent e) {
        controller.ConnecttoServer();
        addController(controller);// 보통 client에 들어가는 것들 (연결확인 이런ㄱ
        JButton click = (JButton) e.getSource();
        if (click == NewGame) {
            msg = "STARTNEWGAME";
            GameRequest(msg, USERTOKEN);
            controller.sendMessage(requestGame);
            String received1 = controller.receiveMessage();//네트워크랑 연결하는 method 수현식 여기다 연결해놓을 것
            String[] parts = received1.split("--");
            if (parts[2].equals("USERNOTLOGGEDIN")) {
                item2.setText("Invalid Token");
            } else if (parts[2].equals("FAILURE")) {
                item2.setText("User already taken, or failed to make game");
            } else if (parts[2].equals("SUCCESS")) {
                item2.setText("Created Game");
                GAMETOKEN = parts[3];
            }
        }
        else if (click == JoinGame) {
            msg = "JOINGAME";
            JoinGameRequest(msg, USERTOKEN, GAMETOKEN);
            controller.sendMessage(requestGame);
            String received1 = controller.receiveMessage();//네트워크랑 연결하는 method 수현식 여기다 연결해놓을 것
            String[] parts = received1.split("--");
            if (parts[2].equals("USERNOTLOGGEDIN")) {
                item2.setText("Invalid Token");
            } else if (parts[2].equals("GAMEKEYNOTFOUND")) {
                item2.setText("Invalid Game Token");
            }else if (parts[2].equals("FAILURE")) {
                item2.setText("Game already started");
            } else if (parts[2].equals("SUCCESS")) {
                item2.setText("Game joined");
                //NEWPARTICIPANT--<username>--<score>
            }
        }
    }
    public void FoilMakerGame_LaunchGame(ActionEvent e) {
        controller.ConnecttoServer();
        addController(controller);// 보통 client에 들어가는 것들 (연결확인 이런ㄱ
        JButton click = (JButton) e.getSource();
        if (click==StartGame){
            msg ="ALLPARTICIPANTSHAVEJOINED";
            AllParticipantRequest(msg, USERTOKEN, GAMETOKEN)
        }
    }
}
