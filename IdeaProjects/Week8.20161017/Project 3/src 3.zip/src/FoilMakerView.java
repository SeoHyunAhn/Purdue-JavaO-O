import com.intellij.refactoring.changeClassSignature.TypeParameterInfo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FoilMakerView extends JFrame implements ActionListener {
    String username, password;
    FoilMakerController controller;
    //Field
    JPanel mainPanel;
    JLabel statusMessageLabel, topMessageLabel;
    private final int FRAME_WIDTH = 400, FRAME_HEIGHT = 600;
    private final int STATUS_PANEL_HIEGHT = 60;
    int MainPanel_WIDTH = FRAME_WIDTH - 10, MainPanel_Height = FRAME_HEIGHT - STATUS_PANEL_HIEGHT;
    int PanelWidget_Width = MainPanel_WIDTH - 20, panelWidget_Height = 40;

    private static enum ViewNames {LOGINVIEW}

    //loginpanel
    JPanel loginViewPanel = null;
    JTextField loginPanelUsername = null;
    JPasswordField loginPanelPassword = null;
    JButton loginPanelLoginButton = null, loginPanelRegisterButton = null;


    public FoilMakerView(FoilMakerController controller){
        this.controller=controller;
    }

    private void setupFrame() {
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BorderLayout());
        mainPanel = new JPanel(new CardLayout());
        mainPanel.setSize(new Dimension(MainPanel_WIDTH, MainPanel_Height));
        statusMessageLabel = new JLabel("Welcome");
        topMessageLabel = new JLabel("FoilMaker!");
        contentPane.add(statusMessageLabel, BorderLayout.SOUTH);
        contentPane.add(topMessageLabel, BorderLayout.NORTH);
        contentPane.add(mainPanel, BorderLayout.CENTER);

        this.setTitle("FoilMaker");
        this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        this.repaint();
    }

    private void createLoginView() {
        JPanel tempPanel1, tempPanel2;
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(5, 5, 5, 5);
        constraints.weightx = 1.0;

        loginViewPanel = new JPanel(new GridLayout());
        loginViewPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        loginViewPanel.setSize(new Dimension(MainPanel_WIDTH, MainPanel_Height));

        loginPanelUsername = new JTextField("Enter user name", 20);
        loginPanelPassword = new JPasswordField("ENter Password", 20);
        loginPanelLoginButton = new JButton("Login");
        loginPanelLoginButton.addActionListener(this);
        loginPanelRegisterButton = new JButton("Register");
        loginPanelRegisterButton.addActionListener(this);

        tempPanel1 = new JPanel(new GridLayout(2, 2));
        tempPanel1.add(new JLabel("User Name"));
        tempPanel1.add(loginPanelUsername);
        tempPanel1.add(new JLabel("Password"));
        tempPanel1.add(loginPanelPassword);

        tempPanel2 = new JPanel(new GridLayout(0, 2));
        tempPanel2.add(loginPanelLoginButton);
        tempPanel2.add(loginPanelRegisterButton);

        constraints.weightx = 0.25;
        constraints.gridx = 0;
        constraints.gridy = 0;

        loginViewPanel.add(new JPanel(), constraints);
        mainPanel.add(loginViewPanel, ViewNames.LOGINVIEW.toString());
    }

    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source instanceof JButton) {
            ButtonLoginRegister(e);
        }
    }

    public void ButtonLoginRegister(ActionEvent e) {
        Object source = e.getSource();
        username = loginPanelUsername.getText();
        password = String.valueOf(loginPanelPassword.getPassword());
        if (source instanceof JButton) {
            JButton button = (JButton) source;
            String a = button.getText();
            if (a.equals(loginPanelLoginButton)) {
                controller.loginUser(username, password);
            } else if (a.equals(loginPanelRegisterButton)) {
                controller.registerUser(username, password);
//            } else if (a.equals(NewGame))
//                controller.newGameLeader();
//            else if (a.equals(JoinGame))
//                controller.joinGame();
//        }
            }
        }
    }


//
//    JTextField field, PW;
//    JLabel labelID, labelPW;
//    JPanel cards;
//    JButton Loginbutton, regbutton, NewGame, JoinGame;
//    private JPanel panel1;
//    private JPanel panel2;
//    private JLabel item1 = new JLabel("FoilMaker");
//     JLabel item2 = new JLabel("Welcome");
//
//    String username, password;
//    private JTextArea output;
//    FoilMakerController controller;
//
//    public FoilMakerView(FoilMakerController controller) {
//        this.controller = controller;
//        //listout pane, make it visible (methods to different kind of view
//    }
//    public void FoilMakerLogin(){
//        setLayout(new FlowLayout());
//        setSize(400, 600);
//        setTitle("FoilMaker");
//        setResizable(false);
//        labelID=new JLabel("Name: ");
//        field=new JTextField("Enter Name");
//        labelPW=new JLabel("PassWord: ");
//        PW=new JTextField("Enter Password");
//        Loginbutton=new JButton("Login");
//        Loginbutton.addActionListener(this);
//        regbutton=new JButton("Register");
//        regbutton.addActionListener(this);
//
//        JPanel tempPanel1 =new JPanel(new GridBagLayout());
//        GridBagConstraints c= new GridBagConstraints();
//        c.fill =GridBagConstraints.HORIZONTAL;
//        c.gridx=1;
//        c.gridy=0;
//        tempPanel1.add(labelID,c);
//
//        c.fill =GridBagConstraints.HORIZONTAL;
//        c.weightx=0.5;
//        c.gridx=3;
//        c.gridwidth=2;
//        c.gridy=0;
//        tempPanel1.add(field,c);
//
//        c.fill =GridBagConstraints.HORIZONTAL;
//        c.gridx=1;
//        c.gridwidth=2;
//        c.gridy=1;
//        tempPanel1.add(labelPW,c);
//
//        c.fill =GridBagConstraints.HORIZONTAL;
//        c.weightx=0.5;
//        c.gridx=3;
//        c.gridy=1;
//        tempPanel1.add(PW,c);
//
//        c.gridx=2;
//        c.gridy=4;
//        tempPanel1.add(Loginbutton, c);
//
//        c.fill =GridBagConstraints.HORIZONTAL;
//        c.gridx=3;
//        c.gridy=4;
//        tempPanel1.add(regbutton, c);
//
//        panel1.add(item1);
//        panel2.add(item2);
//        panel2.setBorder(BorderFactory.createEtchedBorder());
//        panel1.setBorder(BorderFactory.createEtchedBorder());
//        cards.add(panel1, BorderLayout.NORTH);
//        cards.add(tempPanel1, BorderLayout.CENTER);
//        cards.add(panel2, BorderLayout.SOUTH);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//    }
//
//    public void FoilMakerGamestart(){
//        NewGame= new JButton("Start New Game");
//        JoinGame = new JButton("Join a Game");
//        JLabel name = new JLabel(username);
//        //Username
//        panel1.add(name);
//        panel1.remove(item1);
//        add(panel1, BorderLayout.NORTH);
//
//        // Two Buttons
//        JPanel tempPanel2 =new JPanel(new GridBagLayout());
//        GridBagConstraints c = new GridBagConstraints();
//        c.gridx = 0;
//        c.gridy = 0;
//        tempPanel2.add(NewGame,c);
//        c.gridx = 1;
//        c.gridy = 0;
//        tempPanel2.add(JoinGame,c);
//        tempPanel2.setBorder(BorderFactory.createEtchedBorder());
//        cards.add(tempPanel2,BorderLayout.CENTER);
//
//    }
//    public void ButtonLoginRegister(ActionEvent e) {
//        Object source = e.getSource();
//        username=field.getText();
//        password=PW.getText();
//        if (source instanceof JButton) {
//            JButton button =(JButton) source;
//            String a = button.getText();
//            if (a.equals(Loginbutton)){
//            controller.loginUser(username, password);
//            }
//            else if (a.equals(regbutton)){
//                controller.registerUser(username, password);
//            }
//            else if (a.equals(NewGame))
//                controller.newGameLeader();
//            else if  (a.equals(JoinGame))
//                controller.joinGame();
//        }
//    }
//    public void actionPerformed(ActionEvent e) {
//        Object source = e.getSource();
//        if (source instanceof JButton) {
//            ButtonLoginRegister(e);
//        }
//    }
//
//    public void setStatusMessage(String str){
//        item2.setText(str);
//    }
//}